import React, { useState } from 'react';
import { View, Text, TextInput, Button, Keyboard } from 'react-native';
import Estilo from './Estilo';

export default function TelaLeitura({ navigation }) {
  const [texto, setTexto] = useState('');

  const irParaAnalise = () => {
    Keyboard.dismiss();
    // Passamos o texto digitado via parâmetros de navegação para as próximas telas
    navigation.navigate('Contagem', { textoDigitado: texto });
  };

  return (
    <View style={[Estilo.containerBase, { backgroundColor: '#e8f4f8' }]}>
      <Text style={Estilo.titulo}>Digite uma Frase ou Palavra</Text>
      
      <TextInput
        style={Estilo.input}
        placeholder="Ex: Arara ou A mala nada na lama"
        placeholderTextColor="#95a5a6"
        value={texto}
        onChangeText={setTexto}
      />

      <View style={{ width: '100%', marginBottom: 10 }}>
        <Button 
          title="Ver Estatísticas (Vogais/Consoantes)" 
          onPress={irParaAnalise} 
          color="#16a085"
        />
      </View>
      
      <View style={{ width: '100%' }}>
        <Button 
          title="Voltar" 
          onPress={() => navigation.goBack()} 
          color="#7f8c8d"
        />
      </View>
    </View>
  );
}