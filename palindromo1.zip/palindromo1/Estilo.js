import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  containerBase: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  textoBase: {
    fontSize: 22,
    color: '#333',
    textAlign: 'center',
    marginBottom: 15,
  },
  titulo: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    width: '100%',
    height: 50,
    borderColor: '#bdc3c7',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 15,
    backgroundColor: '#fff',
    fontSize: 18,
    marginBottom: 20,
  },
  resultadoBox: {
    marginTop: 20,
    padding: 15,
    backgroundColor: '#ecf0f1',
    borderRadius: 8,
    width: '100%',
    alignItems: 'center',
  },
  textoResultado: {
    fontSize: 18,
    color: '#27ae60',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  textoInstrucao: {
    fontSize: 16,
    color: '#34495e',
    textAlign: 'left',
    lineHeight: 24,
    marginBottom: 10,
  }
});