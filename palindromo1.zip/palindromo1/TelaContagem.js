import React from 'react';
import { View, Text, Button } from 'react-native';
import Estilo from './Estilo';

export default function TelaContagem({ route, navigation }) {
  // Resgata o texto enviado da tela anterior
  const { textoDigitado = '' } = route.params || {};

  // Função para contar vogais e consoantes (removendo acentos e espaços para precisão)
  const analisarLetras = (str) => {
    const limpa = str.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const vogais = (limpa.match(/[aeiou]/g) || []).length;
    const consoantes = (limpa.match(/[b-df-hj-np-tv-z]/g) || []).length;
    return { vogais, consoantes };
  };

  const { vogais, consoantes } = analisarLetras(textoDigitado);

  return (
    <View style={[Estilo.containerBase, { backgroundColor: '#fef9e7' }]}>
      <Text style={Estilo.titulo}>Análise de Caracteres</Text>
      
      <Text style={Estilo.textoBase}>Texto analisado: "{textoDigitado}"</Text>

      <View style={Estilo.resultadoBox}>
        <Text style={Estilo.textoResultado}>Quantidade de Vogais: {vogais}</Text>
        <Text style={[Estilo.textoResultado, { marginTop: 10 }]}>Quantidade de Consoantes: {consoantes}</Text>
      </View>

      <View style={{ width: '100%', marginTop: 30 }}>
        <Button 
          title="Verificar Palíndromo" 
          onPress={() => navigation.navigate('Palindromo', { textoDigitado })} 
          color="#d35400"
        />
      </View>

      <View style={{ width: '100%', marginTop: 10 }}>
        <Button 
          title="Voltar" 
          onPress={() => navigation.goBack()} 
          color="#7f8c8d"
        />
      </View>
    </View>
  );
}