import React from 'react';
import { NavigationContainer, NavigationIndependentTree } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import TelaOrientacoes from './TelaOrientacoes';
import TelaLeitura from './TelaLeitura';
import TelaContagem from './TelaContagem';
import TelaPalindromo from './TelaPalindromo';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationIndependentTree>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Orientações" screenOptions={{ headerShown: true }}>
          <Stack.Screen name="Orientações" component={TelaOrientacoes} />
          <Stack.Screen name="Leitura" component={TelaLeitura} />
          <Stack.Screen name="Contagem" component={TelaContagem} />
          <Stack.Screen name="Palindromo" component={TelaPalindromo} />
        </Stack.Navigator>
      </NavigationContainer>
    </NavigationIndependentTree>
  );
}