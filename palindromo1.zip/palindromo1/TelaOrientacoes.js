import React from 'react';
import { View, Text, Button } from 'react-native';
import Estilo from './Estilo';

export default function TelaOrientacoes({ navigation }) {
  return (
    <View style={[Estilo.containerBase, { backgroundColor: '#f5f6fa' }]}>
      <Text style={Estilo.titulo}>Orientações de Uso</Text>
      
      <Text style={Estilo.textoInstrucao}>1. Na próxima tela, digite uma palavra, frase ou texto completo.</Text>
      <Text style={Estilo.textoInstrucao}>2. O aplicativo verificará automaticamente a quantidade de vogais e consoantes.</Text>
      <Text style={Estilo.textoInstrucao}>3. Na última tela, o sistema informará se o texto digitado é ou não um palíndromo (lê-se igual de trás para frente).</Text>
      
      <View style={{ marginTop: 30, width: '100%' }}>
        <Button 
          title="Avançar para Leitura" 
          onPress={() => navigation.navigate('Leitura')} 
          color="#2980b9"
        />
      </View>
    </View>
  );
}