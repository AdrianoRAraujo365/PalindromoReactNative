import React from 'react';
import { View, Text, Button } from 'react-native';
import Estilo from './Estilo';

export default function TelaPalindromo({ route, navigation }) {
  const { textoDigitado = '' } = route.params || {};

  // Função para checar se é palíndromo
  const verificarPalindromo = (str) => {
    if (!str.trim()) return false;
    // Remove espaços, pontuações e acentos para comparar perfeitamente frases como "A mala nada na lama."
    const limpa = str
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]/g, '');
    
    const reverso = limpa.split('').reverse().join('');
    return limpa === reverso;
  };

  const ehPalindromo = verificarPalindromo(textoDigitado);

  return (
    <View style={[Estilo.containerBase, { backgroundColor: '#e8f8f5' }]}>
      <Text style={Estilo.titulo}>Resultado do Palíndromo</Text>

      <Text style={Estilo.textoBase}>"{textoDigitado}"</Text>

      <View style={[Estilo.resultadoBox, { backgroundColor: ehPalindromo ? '#d4efdf' : '#fadbd8' }]}>
        <Text style={[Estilo.textoResultado, { color: ehPalindromo ? '#196f3d' : '#943126' }]}>
          {ehPalindromo 
            ? 'É um PALÍNDROMO! 🎉' 
            : 'NÃO é um palíndromo.'}
        </Text>
      </View>

      <View style={{ width: '100%', marginTop: 30 }}>
        <Button 
          title="Reiniciar / Início" 
          onPress={() => navigation.navigate('Orientações')} 
          color="#2c3e50"
        />
      </View>
    </View>
  );
}